const Db = [
    { name : "nitin" , email : "nitin@123" , password : "admin" }, 
    { name : "aman" , email : "aman@123" , password : "admin" }, 
    { name : "arpit" , email : "arpit@123" , password : "admin" }, 
    { name : "rahul" , email : "rahul@123" , password : "admin" }, 
]

export default Db