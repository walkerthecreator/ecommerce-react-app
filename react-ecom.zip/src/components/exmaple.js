// const userData = [
//     { email : "aman@123" , password : "1234"} , 
//     { email : "sumit@123" , password : "1234"} , 
//     { email : "vivek@123" , password : "1234"} , 
//     { email : "samar@123" , password : "1234"} 
// ]

// const isLoggedIn = false

// function login(data){

//     const user = userData.findIndex((item)=>{
//         return item.email === data.email
//     })

//     if(user === -1 ) return "user does'not exsit"

//     isLoggedIn = true

//     // redirect to product 

// }

// login({email : "nitin@123" , password :  "admin"})


// const [ user , setUser ] = useState({email : "" , password : "" , isLoggedIn : false })
