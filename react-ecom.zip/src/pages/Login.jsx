import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");

  const navigate = useNavigate()

  function clickHandle() {
    const user = { email: email, password: pass };
    localStorage.setItem("user", JSON.stringify(user));
    navigate('/')
  }


  return (
    <>
    <h1>Login</h1>
    <div className="container w-50 my-5 text-dark">

      <div className="form-floating mb-3">
        <input
          type="email"
          className="form-control"
          id="floatingInput"
          placeholder="name@example.com"
        />
        <label htmlFor="floatingInput">Email address</label>
      </div>
      <div className="form-floating">
        <input
          type="password"
          className="form-control"
          id="floatingPassword"
          placeholder="Password"
        />
        <label htmlFor="floatingPassword">Password</label>
      </div>

      <button className="btn btn-outline-light mt-3" onClick={clickHandle}>Login</button>
        </div>

        <div className="w-50 mx-auto text-center">
          <Link to='/signup'>create new account </Link>
        </div>
    </>
  );
};

export default Login;
